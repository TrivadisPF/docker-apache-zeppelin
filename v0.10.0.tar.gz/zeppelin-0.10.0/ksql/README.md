# Overview
KSQL interpreter for Apache Zeppelin

# Connection
The Interpreter opens a connection with the KSQL REST endpoint.

# Confluent KSQL resources
Following a list of useful resources:
 * [Docs](https://docs.confluent.io/current/ksql/docs/index.html)
 * [Getting Started](https://github.com/confluentinc/demo-scene/blob/master/ksql-intro/demo_ksql-intro.adoc)
