## Groovy Interpreter


[see groovy documentation](../docs/interpreter/groovy.md)
