# Overview
MongoDB interpreter for Apache Zeppelin. Thanksgiving to [bbonnin/zeppelin-mongodb-interpreter](https://github.com/bbonnin/zeppelin-mongodb-interpreter).
I found bbonnin's mongodb interpreter was not working with newest zeppelin version, it has not been maintained for a long time.
so I forked this for those people who want to use mongodb in zeppelin.

### Technical overview
it use mongo shell to execute scripts.All you need to do is to configure mongodb interpreter,
and then study mongo aggregate functions.
